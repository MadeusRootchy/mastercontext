from django.utils import timezone

def global_data(request):

    context={'time':timezone.now()
    }
    return context